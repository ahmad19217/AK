interface Window {
  vueRouter: any;
}
